package com.ashita.myandroidapplication.model

data class FoodFaq(
    val question: String,
    val answer: String
)