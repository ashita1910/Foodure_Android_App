package com.ashita.myandroidapplication.model

data class FoodDetails(
    val foodId: String,
    val foodName: String,
    val foodPrice: String
)